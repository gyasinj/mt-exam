/* MT Exam Manager — Admin JS */
(function($) {
    'use strict';

    // ── Flatpickr DateTime Pickers ──────────────────────────────────────────
    $(document).ready(function() {
        if (typeof flatpickr !== 'undefined') {
            flatpickr('.mt-flatpickr-datetime', {
                enableTime: true,
                dateFormat: 'Y-m-d H:i',
                time_24hr: true,
                allowInput: true,
            });
        }

        // ── AJAX Exam List (if container exists on page) ────────────────────
        if ($('#mt-exam-ajax-list').length) {
            mtLoadExams(1);

            $(document).on('click', '.mt-exam-page-btn', function() {
                var page = $(this).data('page');
                mtLoadExams(page);
            });
        }
    });

    function mtLoadExams(page) {
        var $wrap = $('#mt-exam-ajax-list');
        $wrap.html('<p>Loading exams…</p>');

        $.ajax({
            url: mtExam.ajaxUrl,
            method: 'POST',
            data: {
                action:   'mt_exam_list',
                nonce:    mtExam.nonce,
                page:     page,
                per_page: 10,
            },
            success: function(res) {
                if (!res.success) {
                    $wrap.html('<p>Error loading exams.</p>');
                    return;
                }
                var data = res.data;
                var html = '';

                if (!data.exams || !data.exams.length) {
                    $wrap.html('<p>No exams found.</p>');
                    return;
                }

                html += '<table class="wp-list-table widefat fixed striped">';
                html += '<thead><tr><th>Exam</th><th>Subject</th><th>Term</th><th>Start</th><th>End</th><th>Status</th></tr></thead>';
                html += '<tbody>';

                $.each(data.exams, function(i, exam) {
                    var statusBadge = '';
                    if (exam.status === 'current')  statusBadge = '<span style="background:#28a745;color:#fff;padding:2px 8px;border-radius:4px;font-size:.85em">Ongoing</span>';
                    if (exam.status === 'upcoming') statusBadge = '<span style="background:#007bff;color:#fff;padding:2px 8px;border-radius:4px;font-size:.85em">Upcoming</span>';
                    if (exam.status === 'past')     statusBadge = '<span style="background:#6c757d;color:#fff;padding:2px 8px;border-radius:4px;font-size:.85em">Past</span>';

                    var title = exam.edit_url
                        ? '<a href="' + exam.edit_url + '">' + exam.title + '</a>'
                        : exam.title;

                    html += '<tr>'
                        + '<td>' + title + '</td>'
                        + '<td>' + (exam.subject || '—') + '</td>'
                        + '<td>' + (exam.term    || '—') + '</td>'
                        + '<td>' + (exam.start   || '—') + '</td>'
                        + '<td>' + (exam.end     || '—') + '</td>'
                        + '<td>' + statusBadge + '</td>'
                        + '</tr>';
                });

                html += '</tbody></table>';

                // Pagination
                if (data.total_pages > 1) {
                    html += '<div style="margin-top:12px">';
                    for (var p = 1; p <= data.total_pages; p++) {
                        var active = p === data.page ? 'button-primary' : 'button-secondary';
                        html += '<button class="button ' + active + ' mt-exam-page-btn" data-page="' + p + '" style="margin-right:4px">' + p + '</button>';
                    }
                    html += '<span style="margin-left:10px;color:#666">Total: ' + data.total + ' exams</span>';
                    html += '</div>';
                }

                $wrap.html(html);
            },
            error: function() {
                $wrap.html('<p>AJAX error. Please refresh and try again.</p>');
            }
        });
    }

}(jQuery));
