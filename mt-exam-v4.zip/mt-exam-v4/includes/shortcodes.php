<?php
defined( 'ABSPATH' ) || exit;

/**
 * Shortcodes:
 *  [em_top_students top="5" per_page="5"]
 *  [em_student_result_card title="..."]
 */

// ─────────────────────────────────────────────────────────────────────────────
// [em_top_students]
// ─────────────────────────────────────────────────────────────────────────────
add_shortcode( 'em_top_students', 'mt_exam_top_students_shortcode' );
function mt_exam_top_students_shortcode( $atts ) {
    $atts     = shortcode_atts( [ 'top' => 5, 'per_page' => 5 ], $atts );
    $top_n    = max( 1, intval( $atts['top'] ) );
    $per_page = max( 1, intval( $atts['per_page'] ) );

    static $instance = 0;
    $instance++;
    $wid = 'em-ts-' . $instance; // unique widget ID

    global $wpdb;

    // ── Step 1: All published result posts → exam_id + marks ─────────────────
    $result_rows = $wpdb->get_results(
        "SELECT pm_exam.meta_value AS exam_id,
                pm_marks.meta_value AS marks_serial
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm_exam
               ON pm_exam.post_id = p.ID
              AND pm_exam.meta_key = 'mt_result_exam_id'
         INNER JOIN {$wpdb->postmeta} pm_marks
               ON pm_marks.post_id = p.ID
              AND pm_marks.meta_key = 'mt_result_marks'
         WHERE p.post_type   = 'em_result'
           AND p.post_status = 'publish'",
        ARRAY_A
    );

    if ( empty( $result_rows ) ) {
        return '<p class="em-notice">Abhi koi result record nahi hai. Pehle results enter karein.</p>';
    }

    // ── Step 2: exam → term_id map (bulk) ────────────────────────────────────
    $exam_ids_all = array_unique( array_column( $result_rows, 'exam_id' ) );
    $exam_term_map = []; // exam_id (int) => term_id (int)

    if ( ! empty( $exam_ids_all ) ) {
        $ph = implode( ',', array_fill( 0, count( $exam_ids_all ), '%d' ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT tr.object_id AS exam_id, tt.term_id
             FROM {$wpdb->term_relationships} tr
             INNER JOIN {$wpdb->term_taxonomy} tt
                   ON tt.term_taxonomy_id = tr.term_taxonomy_id
             WHERE tt.taxonomy = 'em_term'
               AND tr.object_id IN ($ph)",
            ...$exam_ids_all
        ), ARRAY_A );
        foreach ( $rows as $r ) {
            $exam_term_map[ intval( $r['exam_id'] ) ] = intval( $r['term_id'] );
        }
    }

    // ── Step 3: Aggregate marks ───────────────────────────────────────────────
    // KEY FIX: marks array keys come back as STRINGS after unserialize.
    // We cast everything to string to keep lookup consistent.
    // group_scores[ group_key ][ student_id_str ] = [ total, count ]
    // group_key = term_id if term assigned, else 'no_term'

    $group_scores  = []; // keyed by group_key
    $group_labels  = []; // group_key => display name

    foreach ( $result_rows as $row ) {
        $exam_id = intval( $row['exam_id'] );
        $marks   = maybe_unserialize( $row['marks_serial'] );
        if ( ! is_array( $marks ) || empty( $marks ) ) continue;

        // Determine group
        if ( isset( $exam_term_map[ $exam_id ] ) ) {
            $group_key = 'term_' . $exam_term_map[ $exam_id ];
            if ( ! isset( $group_labels[ $group_key ] ) ) {
                $term = get_term( $exam_term_map[ $exam_id ], 'em_term' );
                $group_labels[ $group_key ] = $term && ! is_wp_error( $term ) ? $term->name : 'Term #' . $exam_term_map[ $exam_id ];
            }
        } else {
            $group_key = 'no_term';
            $group_labels[ $group_key ] = 'General';
        }

        foreach ( $marks as $sid_raw => $mark_val ) {
            $sid = (string) $sid_raw; // always string key
            if ( ! isset( $group_scores[ $group_key ][ $sid ] ) ) {
                $group_scores[ $group_key ][ $sid ] = [ 'total' => 0.0, 'count' => 0 ];
            }
            $group_scores[ $group_key ][ $sid ]['total'] += floatval( $mark_val );
            $group_scores[ $group_key ][ $sid ]['count'] += 1;
        }
    }

    if ( empty( $group_scores ) ) {
        return '<p class="em-notice">Results mein koi marks nahi mile.</p>';
    }

    // ── Step 4: Student names (bulk) ──────────────────────────────────────────
    $all_sid_strings = [];
    foreach ( $group_scores as $scores ) {
        $all_sid_strings = array_merge( $all_sid_strings, array_keys( $scores ) );
    }
    $all_sid_ints  = array_unique( array_map( 'intval', $all_sid_strings ) );
    $student_names = [];
    if ( ! empty( $all_sid_ints ) ) {
        $sp   = implode( ',', array_fill( 0, count( $all_sid_ints ), '%d' ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts}
             WHERE ID IN ($sp) AND post_type = 'em_student'",
            ...$all_sid_ints
        ), ARRAY_A );
        foreach ( $rows as $r ) {
            $student_names[ (string) $r['ID'] ] = $r['post_title'];
        }
    }

    // ── Step 5: Build ranked tables per group ─────────────────────────────────
    // Sort groups: terms by start date first, then 'no_term' last
    $terms_obj = get_terms( [ 'taxonomy' => 'em_term', 'hide_empty' => false ] );
    $term_order = [];
    if ( ! is_wp_error( $terms_obj ) ) {
        usort( $terms_obj, function( $a, $b ) {
            $da = get_term_meta( $a->term_id, 'mt_term_start_date', true ) ?: '0000-00-00';
            $db = get_term_meta( $b->term_id, 'mt_term_start_date', true ) ?: '0000-00-00';
            return strcmp( $db, $da );
        } );
        foreach ( $terms_obj as $t ) {
            $term_order[] = 'term_' . $t->term_id;
        }
    }
    // Merge: ordered terms first, then any remaining groups
    $ordered_keys = array_merge(
        array_intersect( $term_order, array_keys( $group_scores ) ),
        array_diff( array_keys( $group_scores ), $term_order )
    );

    $panels = []; // [ label, start_date, end_date, rows[] ]
    foreach ( $ordered_keys as $gkey ) {
        $scores = $group_scores[ $gkey ];
        uasort( $scores, function( $a, $b ) {
            $avg_a = $a['count'] ? $a['total'] / $a['count'] : 0;
            $avg_b = $b['count'] ? $b['total'] / $b['count'] : 0;
            return $avg_b <=> $avg_a;
        } );

        $rows   = [];
        $rank   = 1;
        foreach ( array_slice( $scores, 0, $top_n, true ) as $sid => $d ) {
            $avg    = $d['count'] ? round( $d['total'] / $d['count'], 1 ) : 0;
            $rows[] = [
                'rank'  => $rank++,
                'name'  => $student_names[ $sid ] ?? 'Student #' . $sid,
                'total' => number_format( $d['total'], 1 ),
                'count' => $d['count'],
                'avg'   => $avg,
                'grade' => mt_sc_grade( $avg ),
            ];
        }

        // Term dates
        $sd = $ed = '';
        if ( strpos( $gkey, 'term_' ) === 0 ) {
            $tid = intval( substr( $gkey, 5 ) );
            $sd  = get_term_meta( $tid, 'mt_term_start_date', true );
            $ed  = get_term_meta( $tid, 'mt_term_end_date',   true );
        }

        $panels[] = [
            'label'      => $group_labels[ $gkey ] ?? $gkey,
            'start_date' => $sd,
            'end_date'   => $ed,
            'rows'       => $rows,
            'total_rows' => count( $rows ),
        ];
    }

    // ── Step 6: Render HTML ───────────────────────────────────────────────────
    ob_start(); ?>
<div class="em-ts-widget" id="<?php echo esc_attr( $wid ); ?>">

    <div class="em-ts-hdr">
        <span>🏆</span>
        <h2>Top Students</h2>
    </div>

    <div class="em-ts-tabs" role="tablist">
    <?php foreach ( $panels as $pi => $panel ) :
        $date_str = ( $panel['start_date'] || $panel['end_date'] )
            ? ( $panel['start_date'] ?: '?' ) . ' – ' . ( $panel['end_date'] ?: '?' )
            : '';
    ?>
        <button class="em-ts-tab<?php echo $pi === 0 ? ' active' : ''; ?>"
                data-target="<?php echo esc_attr( $wid . '_p' . $pi ); ?>"
                role="tab" aria-selected="<?php echo $pi === 0 ? 'true' : 'false'; ?>">
            <?php echo esc_html( $panel['label'] ); ?>
            <?php if ( $date_str ) : ?>
                <small><?php echo esc_html( $date_str ); ?></small>
            <?php endif; ?>
        </button>
    <?php endforeach; ?>
    </div><!-- .em-ts-tabs -->
 
    <?php foreach ( $panels as $pi => $panel ) :
        $panel_id   = $wid . '_p' . $pi;
        $total_pgs  = $per_page > 0 ? (int) ceil( count( $panel['rows'] ) / $per_page ) : 1;
    ?>
    <div class="em-ts-panel<?php echo $pi === 0 ? ' active' : ''; ?>"
         id="<?php echo esc_attr( $panel_id ); ?>"
         role="tabpanel">

        <table class="em-ts-tbl">
            <thead><tr>
                <th>#</th>
                <th>Student</th>
                <th>Total</th>
                <th>Exams</th>
                <th>Average</th>
                <th>Grade</th>
            </tr></thead>
            <tbody>
            <?php
            $medals = [ 1 => '🥇', 2 => '🥈', 3 => '🥉' ];
            foreach ( $panel['rows'] as $ri => $row ) :
                $page_of_row = (int) floor( $ri / $per_page ); // 0-based page
                $hidden      = $page_of_row > 0 ? ' style="display:none"' : '';
                $gc = 'egr-' . strtolower( str_replace( '+', 'p', $row['grade'] ) );
            ?>
            <tr class="em-tr" data-pg="<?php echo $page_of_row; ?>"<?php echo $hidden; ?>>
                <td><?php echo isset( $medals[ $row['rank'] ] ) ? $medals[ $row['rank'] ] : $row['rank']; ?></td>
                <td><strong><?php echo esc_html( $row['name'] ); ?></strong></td>
                <td><?php echo esc_html( $row['total'] ); ?></td>
                <td><?php echo intval( $row['count'] ); ?></td>
                <td>
                    <div class="em-bar-w">
                        <div class="em-bar-f" style="width:<?php echo min(100,$row['avg']); ?>%"></div>
                        <span><?php echo $row['avg']; ?>/100</span>
                    </div>
                </td>
                <td><span class="em-gr <?php echo $gc; ?>"><?php echo esc_html( $row['grade'] ); ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ( $total_pgs > 1 ) : ?>
        <div class="em-pg" data-panel="<?php echo esc_attr( $panel_id ); ?>" data-total="<?php echo $total_pgs; ?>" data-cur="0">
            <button class="em-pg-btn em-pg-prev" disabled>← Prev</button>
            <span class="em-pg-lbl">Page <b class="em-pg-cur">1</b> of <?php echo $total_pgs; ?></span>
            <button class="em-pg-btn em-pg-next" <?php echo $total_pgs <= 1 ? 'disabled' : ''; ?>>Next →</button>
        </div>
        <?php endif; ?>

    </div><!-- .em-ts-panel -->
    <?php endforeach; ?>

</div><!-- .em-ts-widget -->

<style>
.em-ts-widget{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:880px;margin:20px auto 40px}
.em-ts-hdr{display:flex;align-items:center;gap:10px;margin-bottom:18px}
.em-ts-hdr span{font-size:2em}
.em-ts-hdr h2{margin:0;font-size:1.5em;color:#ffffff}
.em-ts-tabs{display:flex;flex-wrap:wrap;gap:6px;border-bottom:3px solid #dde3ed;margin-bottom:0}
.em-ts-tab{background:none;border:2px solid transparent;border-bottom:none;padding:9px 18px;cursor:pointer;font-size:.9em;font-weight:600;color:#666;border-radius:6px 6px 0 0;position:relative;bottom:-3px;line-height:1.3;transition:color .15s,background .15s}
.em-ts-tab small{display:block;font-size:.72em;font-weight:400;color:#aaa}
.em-ts-tab:hover{color:#0073aa;background:#f2f7fd}
.em-ts-tab.active{color:#0073aa;background:#fff;border-color:#dde3ed #dde3ed #fff;bottom:6px}
.em-ts-tab.active small{color:#5ba4cf}
.em-ts-panel{display:none;background:#fff;border:2px solid #dde3ed;border-top:none;border-radius:0 0 10px 10px;overflow:hidden}
.em-ts-panel.active{display:block}
.em-ts-tbl{width:100%;border-collapse:collapse}
.em-ts-tbl thead tr{background:#f4f7fb}
.em-ts-tbl th{padding:12px 14px;text-align:left;font-size:.78em;text-transform:uppercase;letter-spacing:.05em;color:#555;font-weight:700;border-bottom:2px solid #dde3ed}
.em-ts-tbl td{padding:11px 14px;border-bottom:1px solid #f0f2f8;font-size:.93em;vertical-align:middle;color:#000}
.em-tr:hover td{background:#fafbfe}
.em-tr[data-pg="0"]:nth-child(1) td{background:#fffcf0}
.em-bar-w{display:flex;align-items:center;gap:8px}
.em-bar-f{height:7px;border-radius:6px;background:linear-gradient(90deg,#0073aa,#34c7f5);min-width:3px;max-width:100px;flex-shrink:0}
.em-bar-w span{font-size:.85em;color:#555;white-space:nowrap}
.em-gr{display:inline-block;padding:2px 10px;border-radius:20px;font-weight:700;font-size:.8em}
.egr-ap{background:#d4edda;color:#155724}
.egr-a{background:#d4edda;color:#155724}
.egr-b{background:#cce5ff;color:#004085}
.egr-c{background:#fff3cd;color:#856404}
.egr-d{background:#ffe5d0;color:#7c4900}
.egr-f{background:#f8d7da;color:#721c24}
.em-pg{display:flex;align-items:center;gap:14px;padding:13px 16px;background:#f8f9fc;border-top:1px solid #edf0f8}
.em-pg-btn{background:#fff;border:2px solid #cdd6e4;padding:6px 18px;border-radius:6px;cursor:pointer;font-size:.88em;font-weight:600;color:#444;transition:all .15s}
.em-pg-btn:hover:not(:disabled){background:#0073aa;color:#fff;border-color:#0073aa}
.em-pg-btn:disabled{opacity:.38;cursor:not-allowed}
.em-pg-lbl{flex:1;text-align:center;font-size:.88em;color:#666}
.em-notice{color:#888;font-style:italic;padding:10px 0}
@media(max-width:580px){
  .em-ts-tbl th:nth-child(3),.em-ts-tbl td:nth-child(3),
  .em-ts-tbl th:nth-child(4),.em-ts-tbl td:nth-child(4){display:none}
  .em-bar-f{max-width:55px}
}
</style>

<script>
(function(){
  var w = document.getElementById('<?php echo esc_js( $wid ); ?>');
  if (!w) return;

  /* ── Tabs ── */
  w.querySelectorAll('.em-ts-tab').forEach(function(tab){
    tab.addEventListener('click', function(){
      w.querySelectorAll('.em-ts-tab').forEach(function(t){ t.classList.remove('active'); t.setAttribute('aria-selected','false'); });
      w.querySelectorAll('.em-ts-panel').forEach(function(p){ p.classList.remove('active'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected','true');
      var target = document.getElementById(tab.getAttribute('data-target'));
      if (target) target.classList.add('active');
    });
  });

  /* ── Pagination ── */
  w.querySelectorAll('.em-pg').forEach(function(pg){
    var panelEl  = document.getElementById(pg.getAttribute('data-panel'));
    var total    = parseInt(pg.getAttribute('data-total'), 10);
    var cur      = 0; // 0-based page index
    var prevBtn  = pg.querySelector('.em-pg-prev');
    var nextBtn  = pg.querySelector('.em-pg-next');
    var curLabel = pg.querySelector('.em-pg-cur');

    function go(p){
      cur = p;
      panelEl.querySelectorAll('.em-tr').forEach(function(tr){
        tr.style.display = (parseInt(tr.getAttribute('data-pg'),10) === cur) ? '' : 'none';
      });
      curLabel.textContent = cur + 1;
      prevBtn.disabled = (cur === 0);
      nextBtn.disabled = (cur >= total - 1);
    }
    prevBtn.addEventListener('click', function(){ if(cur>0) go(cur-1); });
    nextBtn.addEventListener('click', function(){ if(cur<total-1) go(cur+1); });
  });
})();
</script>
<?php
    return ob_get_clean();
}

function mt_sc_grade( $avg ) {
    if ( $avg >= 90 ) return 'A+';
    if ( $avg >= 80 ) return 'A';
    if ( $avg >= 70 ) return 'B';
    if ( $avg >= 60 ) return 'C';
    if ( $avg >= 50 ) return 'D';
    return 'F';
}

// ─────────────────────────────────────────────────────────────────────────────
// [em_student_result_card]
// ─────────────────────────────────────────────────────────────────────────────
add_shortcode( 'em_student_result_card', 'mt_exam_result_card_shortcode' );
function mt_exam_result_card_shortcode( $atts ) {
    $atts     = shortcode_atts( [ 'title' => 'Check Your Result Card' ], $atts );
    $ajax_url = admin_url( 'admin-ajax.php' );
    $nonce    = wp_create_nonce( 'mt_exam_nonce' );
    wp_enqueue_script( 'jquery' );

    ob_start(); ?>
<div class="em-rc-widget" style="max-width:760px;margin:0 auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
    <h2 style="color:#1a1a2e;font-size:1.5em;border-bottom:3px solid #0073aa;padding-bottom:10px;margin-bottom:18px">
        <?php echo esc_html( $atts['title'] ); ?>
    </h2>
    <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
        <input type="text" id="em-rc-roll-<?php echo isset($instance) ? $instance : 1; ?>"
               class="em-rc-roll-input"
               placeholder="Roll No / Student ID darj karein"
               style="flex:1;min-width:200px;padding:11px 16px;border:2px solid #cdd6e4;border-radius:8px;font-size:1em;outline:none" />
        <button class="em-rc-search-btn"
                style="padding:11px 26px;background:#0073aa;color:#fff;border:none;border-radius:8px;font-size:1em;font-weight:600;cursor:pointer">
            🔍 Search
        </button>
    </div>
    <div class="em-rc-output"></div>
</div>

<style>
.em-rc-card{background:#fff;border-radius:14px;box-shadow:0 4px 24px rgba(0,0,0,.12);overflow:hidden;margin-top:6px}
.em-rc-head{background:linear-gradient(135deg,#1a1a2e,#0073aa);color:#fff;padding:24px 28px}
.em-rc-head h3{margin:0 0 5px;font-size:1.35em;font-weight:700}
.em-rc-head p{margin:0;opacity:.82;font-size:.9em}
.em-rc-stats{display:flex;border-bottom:2px solid #f0f2f8}
.em-rc-stat{flex:1;text-align:center;padding:15px 8px;border-right:1px solid #f0f2f8}
.em-rc-stat:last-child{border-right:none}
.em-rc-stat strong{display:block;font-size:1.75em;color:#0073aa;font-weight:700}
.em-rc-stat span{font-size:.78em;color:#888}
.em-rc-body{padding:20px 24px;overflow-x:auto}
.em-rc-body table{width:100%;border-collapse:collapse;font-size:.92em}
.em-rc-body th{background:#f4f7fb;padding:11px 12px;text-align:left;font-size:.78em;text-transform:uppercase;letter-spacing:.04em;color:#555;border-bottom:2px solid #dde3ed}
.em-rc-body td{padding:11px 12px;border-bottom:1px solid #f2f4f8;vertical-align:middle}
.em-rc-body tr:last-child td{border-bottom:none}
.em-rc-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-weight:700;font-size:.82em}
.rc-ap,.rc-a{background:#d4edda;color:#155724}
.rc-b{background:#cce5ff;color:#004085}
.rc-c{background:#fff3cd;color:#856404}
.rc-d{background:#ffe5d0;color:#7c4900}
.rc-f{background:#f8d7da;color:#721c24}
.em-rc-error{background:#f8d7da;border:1px solid #f5c2c7;color:#842029;padding:13px 16px;border-radius:8px}
.em-rc-loading{color:#888;font-style:italic;padding:10px 0}
@media(max-width:540px){.em-rc-head{padding:16px 18px}.em-rc-body{padding:14px 16px}.em-rc-stat strong{font-size:1.4em}}
</style>

<script>
(function($){
    function gradeClass(g){
        if(g==='A+') return 'rc-ap';
        if(g==='A')  return 'rc-a';
        if(g==='B')  return 'rc-b';
        if(g==='C')  return 'rc-c';
        if(g==='D')  return 'rc-d';
        return 'rc-f';
    }
    function esc(s){ var d=document.createElement('div'); d.textContent=String(s); return d.innerHTML; }

    $(document).on('click','.em-rc-search-btn', function(){
        var btn    = $(this);
        var widget = btn.closest('.em-rc-widget');
        var roll   = widget.find('.em-rc-roll-input').val().trim();
        var out    = widget.find('.em-rc-output');

        if(!roll){ out.html('<div class="em-rc-error">Roll No / Student ID darj karein.</div>'); return; }

        btn.prop('disabled',true).text('Searching...');
        out.html('<p class="em-rc-loading">Result card load ho raha hai…</p>');

        $.post('<?php echo esc_js($ajax_url); ?>', {
            action  : 'mt_student_result_card',
            nonce   : '<?php echo esc_js($nonce); ?>',
            roll_no : roll
        }, function(res){
            btn.prop('disabled',false).html('🔍 Search');
            if(!res.success){
                out.html('<div class="em-rc-error">'+esc(res.data.message)+'</div>');
                return;
            }
            var d = res.data;
            if(!d.results || d.results.length===0){
                out.html('<div class="em-rc-error">Is student ka koi result nahi mila.</div>');
                return;
            }
            var rows = d.results.map(function(r,i){
                return '<tr>'
                  +'<td>'+(i+1)+'</td>'
                  +'<td>'+esc(r.exam)+'</td>'
                  +'<td>'+esc(r.subject)+'</td>'
                  +'<td>'+esc(r.term)+'</td>'
                  +'<td><strong>'+esc(r.marks)+'/100</strong></td>'
                  +'<td><span class="em-rc-badge '+gradeClass(r.grade)+'">'+esc(r.grade)+'</span></td>'
                  +'<td>'+esc(r.date)+'</td>'
                  +'</tr>';
            }).join('');

            out.html(
              '<div class="em-rc-card">'
             +'<div class="em-rc-head"><h3>'+esc(d.student)+'</h3>'
             +'<p>Roll No: <strong>'+esc(d.roll_no)+'</strong>'+(d.email?' &nbsp;|&nbsp; '+esc(d.email):'')+'</p></div>'
             +'<div class="em-rc-stats">'
             +'<div class="em-rc-stat"><strong>'+esc(d.exams_taken)+'</strong><span>Exams</span></div>'
             +'<div class="em-rc-stat"><strong>'+esc(d.avg)+'</strong><span>Average</span></div>'
             +'<div class="em-rc-stat"><strong>'+esc(d.total_marks)+'</strong><span>Total Marks</span></div>'
             +'</div>'
             +'<div class="em-rc-body"><table>'
             +'<thead><tr><th>#</th><th>Exam</th><th>Subject</th><th>Term</th><th>Marks</th><th>Grade</th><th>Date</th></tr></thead>'
             +'<tbody>'+rows+'</tbody></table></div></div>'
            );
        }).fail(function(){
            btn.prop('disabled',false).html('🔍 Search');
            out.html('<div class="em-rc-error">Server error. Page refresh kar ke dobara try karein.</div>');
        });
    });

    $(document).on('keypress','.em-rc-roll-input',function(e){
        if(e.which===13) $(this).closest('.em-rc-widget').find('.em-rc-search-btn').trigger('click');
    });
})(jQuery);
</script>
<?php
    return ob_get_clean();
}

// Cache clear on result save
add_action( 'save_post_em_result', function() {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_mt_top_students_%'" );
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_mt_top_students_%'" );
} );
