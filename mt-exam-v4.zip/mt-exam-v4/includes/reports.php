<?php
defined( 'ABSPATH' ) || exit;

/**
 * Reports + Dashboard
 * SPEED FIX: Replaced N+1 per-post meta calls with single bulk JOIN queries.
 * NEW: Rich dashboard with stats cards, charts, recent activity.
 * NEW: Student Result Card page (admin view).
 */

// ─── Dashboard ────────────────────────────────────────────────────────────────
function mt_exam_dashboard_page() {
    global $wpdb;

    // Counts (fast — WP caches these)
    $students = wp_count_posts('em_student')->publish ?? 0;
    $subjects = wp_count_posts('em_subject')->publish ?? 0;
    $exams    = wp_count_posts('em_exam')->publish    ?? 0;
    $results  = wp_count_posts('em_result')->publish  ?? 0;

    // Fetch all result marks in one query
    $result_posts_raw = $wpdb->get_results(
        "SELECT pm.meta_value AS marks_serial
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'mt_result_marks'
         WHERE p.post_type = 'em_result' AND p.post_status = 'publish'",
        ARRAY_A
    );

    $student_totals = [];
    foreach ( $result_posts_raw as $row ) {
        $marks = maybe_unserialize( $row['marks_serial'] );
        if ( ! is_array( $marks ) ) continue;
        foreach ( $marks as $sid => $m ) {
            $sid = intval($sid);
            if ( ! isset( $student_totals[$sid] ) ) $student_totals[$sid] = ['total'=>0,'count'=>0];
            $student_totals[$sid]['total'] += floatval($m);
            $student_totals[$sid]['count'] += 1;
        }
    }

    // Sort by avg
    uasort( $student_totals, fn($a,$b) =>
        ($b['count'] ? $b['total']/$b['count'] : 0) <=> ($a['count'] ? $a['total']/$a['count'] : 0)
    );
    $top5_ids = array_slice( array_keys($student_totals), 0, 5, true );

    $top5 = [];
    foreach ( $top5_ids as $sid ) {
        $name = get_the_title($sid) ?: "Student #$sid";
        $d    = $student_totals[$sid];
        $top5[] = [ 'name' => $name, 'avg' => $d['count'] ? round($d['total']/$d['count'],1) : 0, 'total' => $d['total'], 'exams' => $d['count'] ];
    }

    // Recent exams (last 5)
    $recent_exams = $wpdb->get_results(
        "SELECT p.ID, p.post_title,
                MAX(CASE WHEN pm.meta_key='mt_exam_start_datetime' THEN pm.meta_value END) AS start_dt,
                MAX(CASE WHEN pm.meta_key='mt_exam_subject_id'     THEN pm.meta_value END) AS subj_id
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
         WHERE p.post_type = 'em_exam' AND p.post_status = 'publish'
         GROUP BY p.ID ORDER BY p.post_date DESC LIMIT 5",
        ARRAY_A
    );

    // Pending (upcoming) exams count
    $now = current_time('Y-m-d H:i:s');
    $upcoming_count = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT p.ID)
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'mt_exam_start_datetime'
         WHERE p.post_type = 'em_exam' AND p.post_status = 'publish' AND pm.meta_value > %s",
        $now
    ) );

    // Avg marks across all results
    $all_avgs = [];
    foreach ( $student_totals as $d ) {
        if ($d['count']) $all_avgs[] = $d['total'] / $d['count'];
    }
    $global_avg = count($all_avgs) ? round( array_sum($all_avgs)/count($all_avgs), 1 ) : 0;

    // Chart data — marks distribution buckets
    $buckets = [ 'F (0-49)'=>0,'D (50-59)'=>0,'C (60-69)'=>0,'B (70-79)'=>0,'A (80-89)'=>0,'A+ (90+)'=>0 ];
    foreach ( $result_posts_raw as $row ) {
        $marks = maybe_unserialize( $row['marks_serial'] );
        if ( ! is_array($marks) ) continue;
        foreach ( $marks as $m ) {
            $m = floatval($m);
            if ($m < 50) $buckets['F (0-49)']++;
            elseif ($m < 60) $buckets['D (50-59)']++;
            elseif ($m < 70) $buckets['C (60-69)']++;
            elseif ($m < 80) $buckets['B (70-79)']++;
            elseif ($m < 90) $buckets['A (80-89)']++;
            else $buckets['A+ (90+)']++;
        }
    }
    $total_graded = array_sum($buckets) ?: 1;
    ?>
    <div class="wrap mt-exam-dashboard">
        <h1>📊 MT Exam Manager — Dashboard</h1>

        <!-- Stat Cards -->
        <div class="mt-stat-cards">
            <div class="mt-stat-card blue">
                <span class="dashicons dashicons-groups"></span>
                <strong><?php echo $students; ?></strong>
                <p>Students</p>
                <a href="<?php echo admin_url('edit.php?post_type=em_student'); ?>">Manage →</a>
            </div>
            <div class="mt-stat-card green">
                <span class="dashicons dashicons-book-alt"></span>
                <strong><?php echo $subjects; ?></strong>
                <p>Subjects</p>
                <a href="<?php echo admin_url('edit.php?post_type=em_subject'); ?>">Manage →</a>
            </div>
            <div class="mt-stat-card orange">
                <span class="dashicons dashicons-clipboard"></span>
                <strong><?php echo $exams; ?></strong>
                <p>Exams</p>
                <small><?php echo $upcoming_count; ?> upcoming</small>
                <a href="<?php echo admin_url('edit.php?post_type=em_exam'); ?>">Manage →</a>
            </div>
            <div class="mt-stat-card purple">
                <span class="dashicons dashicons-chart-bar"></span>
                <strong><?php echo $results; ?></strong>
                <p>Result Records</p>
                <a href="<?php echo admin_url('edit.php?post_type=em_result'); ?>">Manage →</a>
            </div>
            <div class="mt-stat-card teal">
                <span class="dashicons dashicons-star-filled"></span>
                <strong><?php echo $global_avg ?: '—'; ?></strong>
                <p>Overall Avg Marks</p>
                <small>out of 100</small>
            </div>
        </div>

        <div class="mt-dashboard-grid">

            <!-- Top 5 Students -->
            <div class="mt-dash-box">
                <h2>🏆 Top 5 Students (by Average)</h2>
                <?php if ( empty($top5) ) : ?>
                    <p class="mt-muted">No results entered yet.</p>
                <?php else : ?>
                <table class="mt-dash-table">
                    <thead><tr><th>#</th><th>Student</th><th>Avg</th><th>Exams</th></tr></thead>
                    <tbody>
                    <?php $medal = ['🥇','🥈','🥉']; foreach ($top5 as $i => $s) : ?>
                        <tr>
                            <td><?php echo $medal[$i] ?? ($i+1); ?></td>
                            <td><?php echo esc_html($s['name']); ?></td>
                            <td>
                                <div class="mt-bar-wrap">
                                    <div class="mt-bar" style="width:<?php echo $s['avg']; ?>%"></div>
                                    <span><?php echo $s['avg']; ?>/100</span>
                                </div>
                            </td>
                            <td><?php echo $s['exams']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <!-- Marks Distribution Chart -->
            <div class="mt-dash-box">
                <h2>📊 Grade Distribution</h2>
                <?php if ( $total_graded <= 1 ) : ?>
                    <p class="mt-muted">No marks data yet.</p>
                <?php else : ?>
                <div class="mt-grade-chart">
                    <?php
                    $colors = ['#e74c3c','#e67e22','#f1c40f','#2ecc71','#3498db','#9b59b6'];
                    $ci = 0;
                    foreach ($buckets as $label => $cnt) :
                        $pct = round($cnt / $total_graded * 100, 1);
                    ?>
                    <div class="mt-grade-row">
                        <span class="mt-grade-label"><?php echo esc_html($label); ?></span>
                        <div class="mt-grade-bar-wrap">
                            <div class="mt-grade-bar" style="width:<?php echo $pct; ?>%;background:<?php echo $colors[$ci]; ?>"></div>
                        </div>
                        <span class="mt-grade-count"><?php echo $cnt; ?> (<?php echo $pct; ?>%)</span>
                    </div>
                    <?php $ci++; endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Recent Exams -->
            <div class="mt-dash-box">
                <h2>🗓 Recent Exams</h2>
                <?php if ( empty($recent_exams) ) : ?>
                    <p class="mt-muted">No exams added yet.</p>
                <?php else : ?>
                <table class="mt-dash-table">
                    <thead><tr><th>Exam</th><th>Subject</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach ($recent_exams as $ex) :
                        $subj = $ex['subj_id'] ? get_the_title($ex['subj_id']) : '—';
                        $date = $ex['start_dt'] ? date('d M Y', strtotime($ex['start_dt'])) : '—';
                    ?>
                        <tr>
                            <td><a href="<?php echo get_edit_post_link($ex['ID']); ?>"><?php echo esc_html($ex['post_title']); ?></a></td>
                            <td><?php echo esc_html($subj); ?></td>
                            <td><?php echo esc_html($date); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <!-- Quick Actions -->
            <div class="mt-dash-box">
                <h2>⚡ Quick Actions</h2>
                <div class="mt-quick-links">
                    <a href="<?php echo admin_url('post-new.php?post_type=em_student'); ?>" class="mt-qlink blue">
                        <span class="dashicons dashicons-plus-alt"></span> Add Student
                    </a>
                    <a href="<?php echo admin_url('post-new.php?post_type=em_subject'); ?>" class="mt-qlink green">
                        <span class="dashicons dashicons-plus-alt"></span> Add Subject
                    </a>
                    <a href="<?php echo admin_url('post-new.php?post_type=em_exam'); ?>" class="mt-qlink orange">
                        <span class="dashicons dashicons-plus-alt"></span> Add Exam
                    </a>
                    <a href="<?php echo admin_url('post-new.php?post_type=em_result'); ?>" class="mt-qlink purple">
                        <span class="dashicons dashicons-plus-alt"></span> Enter Results
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=mt-exam-import'); ?>" class="mt-qlink teal">
                        <span class="dashicons dashicons-upload"></span> Import CSV
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=mt-exam-report'); ?>" class="mt-qlink dark">
                        <span class="dashicons dashicons-chart-area"></span> Full Report
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=mt-exam-result-card'); ?>" class="mt-qlink red">
                        <span class="dashicons dashicons-id"></span> Result Card
                    </a>
                </div>
            </div>

        </div><!-- .mt-dashboard-grid -->
    </div>

    <style>
    .mt-exam-dashboard { max-width: 1200px; }
    .mt-stat-cards { display:flex; flex-wrap:wrap; gap:16px; margin:20px 0 30px; }
    .mt-stat-card { flex:1; min-width:160px; background:#fff; border-radius:12px; padding:18px 20px; box-shadow:0 2px 10px rgba(0,0,0,.08); border-top:4px solid #ccc; position:relative; }
    .mt-stat-card.blue   { border-color:#3498db; } .mt-stat-card.green { border-color:#2ecc71; }
    .mt-stat-card.orange { border-color:#e67e22; } .mt-stat-card.purple{ border-color:#9b59b6; }
    .mt-stat-card.teal   { border-color:#1abc9c; }
    .mt-stat-card .dashicons { font-size:28px; color:#bbb; float:right; margin-top:-4px; }
    .mt-stat-card strong { display:block; font-size:2.2em; line-height:1.1; color:#1a1a2e; }
    .mt-stat-card p { margin:2px 0 4px; color:#555; font-size:.95em; }
    .mt-stat-card small { color:#888; font-size:.8em; display:block; margin-bottom:6px; }
    .mt-stat-card a { font-size:.8em; color:#0073aa; text-decoration:none; }

    .mt-dashboard-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
    @media(max-width:900px){.mt-dashboard-grid{grid-template-columns:1fr;}}
    .mt-dash-box { background:#fff; border-radius:12px; padding:22px 24px; box-shadow:0 2px 10px rgba(0,0,0,.07); }
    .mt-dash-box h2 { margin-top:0; font-size:1.1em; border-bottom:1px solid #f0f0f0; padding-bottom:10px; margin-bottom:14px; }
    .mt-muted { color:#aaa; font-style:italic; }

    .mt-dash-table { width:100%; border-collapse:collapse; font-size:.9em; }
    .mt-dash-table th { background:#f8f9fa; padding:7px 10px; text-align:left; color:#555; }
    .mt-dash-table td { padding:7px 10px; border-bottom:1px solid #f5f5f5; }
    .mt-dash-table a { color:#0073aa; text-decoration:none; }

    .mt-bar-wrap { display:flex; align-items:center; gap:8px; }
    .mt-bar { height:8px; background:#3498db; border-radius:4px; min-width:2px; max-width:120px; }
    .mt-bar-wrap span { font-size:.85em; color:#555; white-space:nowrap; }

    .mt-grade-chart { display:flex; flex-direction:column; gap:10px; }
    .mt-grade-row { display:flex; align-items:center; gap:10px; font-size:.88em; }
    .mt-grade-label { width:90px; color:#555; flex-shrink:0; font-size:.82em; }
    .mt-grade-bar-wrap { flex:1; background:#f0f0f0; border-radius:4px; height:14px; overflow:hidden; }
    .mt-grade-bar { height:100%; border-radius:4px; transition:width .4s; }
    .mt-grade-count { width:90px; color:#666; font-size:.8em; text-align:right; flex-shrink:0; }

    .mt-quick-links { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    .mt-qlink { display:flex; align-items:center; gap:8px; padding:10px 14px; border-radius:8px; text-decoration:none; font-size:.88em; font-weight:600; color:#fff; transition:opacity .2s; }
    .mt-qlink:hover { opacity:.85; color:#fff; }
    .mt-qlink .dashicons { font-size:16px; height:16px; width:16px; }
    .mt-qlink.blue   { background:#3498db; } .mt-qlink.green { background:#2ecc71; }
    .mt-qlink.orange { background:#e67e22; } .mt-qlink.purple{ background:#9b59b6; }
    .mt-qlink.teal   { background:#1abc9c; } .mt-qlink.dark  { background:#34495e; }
    .mt-qlink.red    { background:#e74c3c; }
    </style>
    <?php
}

// ─── Student Report (Admin) ────────────────────────────────────────────────────
function mt_exam_report_page() {
    $export_pdf = isset( $_GET['export_pdf'] ) && current_user_can( 'manage_options' );
    $report     = mt_exam_build_report();

    if ( $export_pdf ) {
        mt_exam_export_pdf( $report );
        exit;
    }
    ?>
    <div class="wrap mt-exam-report">
        <h1>📊 Student Statistics Report</h1>
        <div class="mt-report-actions" style="margin-bottom:16px;">
            <a href="<?php echo esc_url( add_query_arg( ['page'=>'mt-exam-report','export_pdf'=>1], admin_url('admin.php') ) ); ?>"
               class="button button-primary" target="_blank">🖨 Export as PDF</a>
        </div>

        <?php if ( empty( $report['students'] ) ) : ?>
            <p class="notice notice-warning">No students found.</p>
        <?php else : ?>
        <div style="overflow-x:auto;margin-top:10px">
        <table class="wp-list-table widefat fixed striped">
            <thead><tr>
                <th>Student</th>
                <?php foreach ( $report['terms'] as $term ) : ?>
                    <th><?php echo esc_html($term->name); ?><br/><small><?php echo esc_html(mt_exam_term_dates($term->term_id)); ?></small></th>
                <?php endforeach; ?>
                <th>Total</th><th>Avg/Term</th><th>Overall Avg</th>
            </tr></thead>
            <tbody>
            <?php foreach ( $report['students'] as $stu_id => $stu ) :
                $grand  = array_sum($stu['term_totals']);
                $ecnt   = array_sum($stu['term_exam_count']);
                $oavg   = $ecnt ? round($grand/$ecnt,1) : '—';
                $nt     = count(array_filter($stu['term_totals']));
                $tavg   = $nt ? round($grand/$nt,1) : '—';
            ?>
            <tr>
                <td><strong><?php echo esc_html($stu['name']); ?></strong></td>
                <?php foreach ($report['terms'] as $term) :
                    $tid  = $term->term_id;
                    $tot  = $stu['term_totals'][$tid] ?? null;
                    $cnt  = $stu['term_exam_count'][$tid] ?? 0;
                ?>
                <td><?php echo $tot !== null ? number_format($tot,1) : '—';
                    echo $cnt ? "<br/><small style='color:#888'>$cnt exams</small>" : ''; ?></td>
                <?php endforeach; ?>
                <td><strong><?php echo number_format($grand,1); ?></strong></td>
                <td><?php echo $tavg; ?></td>
                <td><?php echo $oavg; ?>/100</td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php endif; ?>
    </div>
    <?php
}

// ─── Admin Result Card Page ────────────────────────────────────────────────────
function mt_exam_result_card_page() {
    ?>
    <div class="wrap mt-exam-result-card-admin">
        <h1>🪪 Student Result Card</h1>
        <p class="description">Student ka Roll No / ID enter karein to result card dekhein.</p>

        <div style="max-width:400px;margin:20px 0">
            <input type="text" id="mt-admin-roll" class="regular-text" placeholder="Enter Student Roll No / ID" style="width:100%;margin-bottom:10px;" />
            <button class="button button-primary" id="mt-admin-search-btn" style="width:100%">🔍 Search Result Card</button>
        </div>

        <div id="mt-admin-result-output"></div>
    </div>

    <style>
    .mt-result-card { background:#fff; border-radius:14px; box-shadow:0 4px 20px rgba(0,0,0,.1); max-width:700px; overflow:hidden; margin-top:20px; }
    .mt-rc-header { background:linear-gradient(135deg,#1a1a2e,#0073aa); color:#fff; padding:24px 28px; }
    .mt-rc-header h2 { margin:0 0 4px; font-size:1.5em; }
    .mt-rc-header p { margin:0; opacity:.8; font-size:.9em; }
    .mt-rc-stats { display:flex; gap:0; border-bottom:1px solid #f0f0f0; }
    .mt-rc-stat { flex:1; text-align:center; padding:16px 10px; border-right:1px solid #f0f0f0; }
    .mt-rc-stat:last-child { border-right:none; }
    .mt-rc-stat strong { display:block; font-size:1.8em; color:#0073aa; }
    .mt-rc-stat span { font-size:.8em; color:#888; }
    .mt-rc-body { padding:20px 28px; }
    .mt-rc-body table { width:100%; border-collapse:collapse; font-size:.9em; }
    .mt-rc-body th { background:#f4f6f9; padding:10px 12px; text-align:left; color:#555; }
    .mt-rc-body td { padding:10px 12px; border-bottom:1px solid #f5f5f5; }
    .mt-grade-badge { display:inline-block; padding:2px 10px; border-radius:20px; font-weight:700; font-size:.85em; }
    .grade-Aplus,.grade-A { background:#d4edda; color:#155724; }
    .grade-B { background:#cce5ff; color:#004085; }
    .grade-C { background:#fff3cd; color:#856404; }
    .grade-D { background:#ffe5d0; color:#7c4900; }
    .grade-F { background:#f8d7da; color:#721c24; }
    </style>

    <script>
    jQuery(function($){
        function searchCard() {
            var roll = $('#mt-admin-roll').val().trim();
            if (!roll) { alert('Roll No enter karein'); return; }
            var btn = $('#mt-admin-search-btn');
            btn.prop('disabled',true).text('Searching...');
            $.post(mtExam.ajaxUrl, {
                action:'mt_student_result_card', nonce:mtExam.nonce, roll_no:roll
            }, function(res){
                btn.prop('disabled',false).text('🔍 Search Result Card');
                if (!res.success) {
                    $('#mt-admin-result-output').html('<div class="notice notice-error"><p>'+res.data.message+'</p></div>');
                    return;
                }
                var d = res.data;
                var gradeClass = 'grade-' + d.results[0].grade.replace('+','plus');
                var rows = d.results.map(function(r,i){
                    var gc = 'grade-'+(r.grade==='A+'?'Aplus':r.grade);
                    return '<tr><td>'+(i+1)+'</td><td>'+escH(r.exam)+'</td><td>'+escH(r.subject)+'</td><td>'+escH(r.term)+'</td><td>'+r.marks+'/100</td><td><span class="mt-grade-badge '+gc+'">'+r.grade+'</span></td><td>'+escH(r.date)+'</td></tr>';
                }).join('');
                var html = '<div class="mt-result-card">'
                    +'<div class="mt-rc-header"><h2>'+escH(d.student)+'</h2><p>Roll No: '+escH(d.roll_no)+(d.email?' &nbsp;|&nbsp; '+escH(d.email):'')+'</p></div>'
                    +'<div class="mt-rc-stats">'
                    +'<div class="mt-rc-stat"><strong>'+d.exams_taken+'</strong><span>Exams Taken</span></div>'
                    +'<div class="mt-rc-stat"><strong>'+d.avg+'</strong><span>Avg Marks</span></div>'
                    +'<div class="mt-rc-stat"><strong>'+d.total_marks+'</strong><span>Total Marks</span></div>'
                    +'</div>'
                    +'<div class="mt-rc-body"><table><thead><tr><th>#</th><th>Exam</th><th>Subject</th><th>Term</th><th>Marks</th><th>Grade</th><th>Date</th></tr></thead><tbody>'+rows+'</tbody></table></div>'
                    +'</div>';
                $('#mt-admin-result-output').html(html);
            });
        }
        function escH(s){ var d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
        $('#mt-admin-search-btn').on('click', searchCard);
        $('#mt-admin-roll').on('keypress',function(e){ if(e.which===13) searchCard(); });
    });
    </script>
    <?php
}

// ─── Build Report Data (Speed Fixed) ──────────────────────────────────────────
function mt_exam_build_report() {
    global $wpdb;

    $terms = get_terms( [ 'taxonomy' => 'em_term', 'hide_empty' => false ] );
    if ( is_wp_error($terms) ) $terms = [];
    usort( $terms, function($a,$b){
        $da = get_term_meta($a->term_id,'mt_term_start_date',true) ?: '0000-00-00';
        $db = get_term_meta($b->term_id,'mt_term_start_date',true) ?: '0000-00-00';
        return strcmp($db,$da);
    });

    // SPEED FIX: exam→term in ONE query
    $exam_term_map = [];
    if ( ! empty($terms) ) {
        $term_ids = wp_list_pluck($terms,'term_id');
        $tp = implode(',', array_fill(0,count($term_ids),'%d'));
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT tr.object_id AS exam_id, tt.term_id
             FROM {$wpdb->term_relationships} tr
             INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             WHERE tt.taxonomy = 'em_term' AND tt.term_id IN ($tp)",
            ...$term_ids
        ), ARRAY_A);
        foreach ($rows as $r) $exam_term_map[$r['exam_id']] = (int)$r['term_id'];
    }

    // SPEED FIX: all result marks in ONE query
    $result_rows = $wpdb->get_results(
        "SELECT pm_exam.meta_value AS exam_id, pm_marks.meta_value AS marks_serial
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm_exam  ON pm_exam.post_id  = p.ID AND pm_exam.meta_key  = 'mt_result_exam_id'
         INNER JOIN {$wpdb->postmeta} pm_marks ON pm_marks.post_id = p.ID AND pm_marks.meta_key = 'mt_result_marks'
         WHERE p.post_type = 'em_result' AND p.post_status = 'publish'",
        ARRAY_A
    );

    $student_posts = get_posts(['post_type'=>'em_student','numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);
    $students_data = [];
    foreach ($student_posts as $stu) {
        $students_data[$stu->ID] = ['name'=>$stu->post_title,'term_totals'=>[],'term_exam_count'=>[]];
    }

    foreach ($result_rows as $row) {
        $exam_id = intval($row['exam_id']);
        $marks   = maybe_unserialize($row['marks_serial']);
        if ( !is_array($marks) || !isset($exam_term_map[$exam_id]) ) continue;
        $term_id = $exam_term_map[$exam_id];
        foreach ($marks as $student_id => $mark) {
            $student_id = intval($student_id);
            if ( !isset($students_data[$student_id]) ) continue;
            $students_data[$student_id]['term_totals'][$term_id]     = ($students_data[$student_id]['term_totals'][$term_id] ?? 0) + floatval($mark);
            $students_data[$student_id]['term_exam_count'][$term_id] = ($students_data[$student_id]['term_exam_count'][$term_id] ?? 0) + 1;
        }
    }

    return ['terms'=>$terms,'students'=>$students_data];
}

function mt_exam_term_dates($term_id) {
    $s = get_term_meta($term_id,'mt_term_start_date',true);
    $e = get_term_meta($term_id,'mt_term_end_date',true);
    if ($s||$e) return ($s?:'?').' – '.($e?:'?');
    return '';
}

function mt_exam_export_pdf($report) {
    ?><!DOCTYPE html><html><head><meta charset="UTF-8">
    <title>Student Report – <?php echo date('Y-m-d'); ?></title>
    <style>
    *{box-sizing:border-box}body{font-family:Arial,sans-serif;font-size:12px;color:#222;margin:20px}
    h1{font-size:20px;color:#0073aa;text-align:center}.subtitle{text-align:center;color:#666;margin-bottom:20px;font-size:11px}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th{background:#0073aa;color:#fff;padding:8px 6px;text-align:left;font-size:11px}
    td{padding:7px 6px;border-bottom:1px solid #e0e0e0;font-size:11px}
    tr:nth-child(even) td{background:#f9f9f9}.bold{font-weight:bold}
    .footer{text-align:center;margin-top:30px;font-size:10px;color:#aaa}
    @media print{body{margin:0}@page{margin:1cm}}
    </style></head><body>
    <h1>Student Statistics Report</h1>
    <p class="subtitle">Generated: <?php echo date('F j, Y \a\t H:i'); ?></p>
    <?php if (!empty($report['students'])) : ?>
    <table><thead><tr><th>#</th><th>Student</th>
    <?php foreach ($report['terms'] as $t) echo '<th>'.esc_html($t->name).'</th>'; ?>
    <th>Total</th><th>Avg</th></tr></thead><tbody>
    <?php $i=1; foreach ($report['students'] as $stu_id => $stu) :
        $gt = array_sum($stu['term_totals']); $ec = array_sum($stu['term_exam_count']);
        $oa = $ec ? round($gt/$ec,1) : '—'; ?>
    <tr><td><?php echo $i++; ?></td><td class="bold"><?php echo esc_html($stu['name']); ?></td>
    <?php foreach ($report['terms'] as $t) {
        $tid = $t->term_id; $tot = $stu['term_totals'][$tid] ?? null;
        echo '<td>'.($tot!==null?number_format($tot,1):'—').'</td>';
    } ?>
    <td class="bold"><?php echo number_format($gt,1); ?></td><td><?php echo $oa; ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php endif; ?>
    <p class="footer">MT Exam Manager | <?php echo esc_html(get_bloginfo('name')); ?></p>
    <script>window.onload=function(){window.print()}</script>
    </body></html>
    <?php
}
