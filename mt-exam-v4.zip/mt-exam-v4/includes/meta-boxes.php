<?php
defined( 'ABSPATH' ) || exit;

/**
 * Feature 2: Admin Exam Creation – meta boxes
 * Feature 3: Result Creation – student marks entry
 */

add_action( 'add_meta_boxes', 'mt_exam_register_meta_boxes' );
function mt_exam_register_meta_boxes() {

    // ── Exam Fields ───────────────────────────────────────────────────────────
    add_meta_box(
        'mt_exam_details',
        'Exam Details',
        'mt_exam_details_meta_box',
        'em_exam',
        'normal',
        'high'
    );

    // ── Student Fields ────────────────────────────────────────────────────────
    add_meta_box(
        'mt_student_details',
        'Student Details',
        'mt_student_details_meta_box',
        'em_student',
        'normal',
        'high'
    );

    // ── Result Fields ─────────────────────────────────────────────────────────
    add_meta_box(
        'mt_result_details',
        'Enter Results for Exam',
        'mt_result_details_meta_box',
        'em_result',
        'normal',
        'high'
    );
}

// ─── Exam Meta Box ─────────────────────────────────────────────────────────────
function mt_exam_details_meta_box( $post ) {
    wp_nonce_field( 'mt_exam_save', 'mt_exam_nonce' );

    $start_dt = get_post_meta( $post->ID, 'mt_exam_start_datetime', true );
    $end_dt   = get_post_meta( $post->ID, 'mt_exam_end_datetime',   true );
    $subject  = get_post_meta( $post->ID, 'mt_exam_subject_id',     true );

    $subjects = get_posts( [ 'post_type' => 'em_subject', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
    ?>
    <p class="description" style="margin-bottom:12px;">
        CSV import mein <strong>exam_id</strong> column mein is exam ka <strong>WordPress Post ID</strong> use karein
        — Post ID upar title ke saath bracket mein dikh raha hai (e.g. <em>Edit Exam #42</em>).
    </p>
    <table class="mt-meta-table">
        <tr>
            <th><label for="mt_exam_start_datetime">Start Date & Time <span class="required">*</span></label></th>
            <td>
                <input type="text" id="mt_exam_start_datetime" name="mt_exam_start_datetime"
                       class="mt-flatpickr-datetime" value="<?php echo esc_attr( $start_dt ); ?>"
                       placeholder="YYYY-MM-DD HH:MM" required />
            </td>
        </tr>
        <tr>
            <th><label for="mt_exam_end_datetime">End Date & Time <span class="required">*</span></label></th>
            <td>
                <input type="text" id="mt_exam_end_datetime" name="mt_exam_end_datetime"
                       class="mt-flatpickr-datetime" value="<?php echo esc_attr( $end_dt ); ?>"
                       placeholder="YYYY-MM-DD HH:MM" required />
            </td>
        </tr>
        <tr>
            <th><label for="mt_exam_subject_id">Subject <span class="required">*</span></label></th>
            <td>
                <select id="mt_exam_subject_id" name="mt_exam_subject_id" required>
                    <option value="">— Select Subject —</option>
                    <?php foreach ( $subjects as $s ) : ?>
                        <option value="<?php echo $s->ID; ?>" <?php selected( $subject, $s->ID ); ?>>
                            <?php echo esc_html( $s->post_title ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <p class="description" style="margin-top:12px;">
        Assign an <strong>Academic Term</strong> using the <em>Academic Terms</em> box on the right sidebar.
    </p>
    <?php
}

// ─── Student Meta Box ──────────────────────────────────────────────────────────
function mt_student_details_meta_box( $post ) {
    wp_nonce_field( 'mt_student_save', 'mt_student_nonce' );
    $student_id  = get_post_meta( $post->ID, 'mt_student_id',    true );
    $student_email = get_post_meta( $post->ID, 'mt_student_email', true );
    ?>
    <table class="mt-meta-table">
        <tr>
            <th><label for="mt_student_id">Student Roll/ID</label></th>
            <td><input type="text" id="mt_student_id" name="mt_student_id"
                       value="<?php echo esc_attr( $student_id ); ?>" class="regular-text" /></td>
        </tr>
        <tr>
            <th><label for="mt_student_email">Email Address</label></th>
            <td><input type="email" id="mt_student_email" name="mt_student_email"
                       value="<?php echo esc_attr( $student_email ); ?>" class="regular-text" /></td>
        </tr>
    </table>
    <?php
}

// ─── Result Meta Box ──────────────────────────────────────────────────────────
function mt_result_details_meta_box( $post ) {
    wp_nonce_field( 'mt_result_save', 'mt_result_nonce' );

    $exam_id      = get_post_meta( $post->ID, 'mt_result_exam_id', true );
    $saved_marks  = get_post_meta( $post->ID, 'mt_result_marks',   true ) ?: [];

    $exams = get_posts( [
        'post_type'   => 'em_exam',
        'numberposts' => -1,
        'orderby'     => 'title',
        'order'       => 'ASC',
    ] );

    $students = get_posts( [
        'post_type'   => 'em_student',
        'numberposts' => -1,
        'orderby'     => 'title',
        'order'       => 'ASC',
    ] );
    ?>
    <div class="mt-result-box">
        <p>
            <label for="mt_result_exam_id"><strong>Select Exam:</strong></label><br/>
            <select id="mt_result_exam_id" name="mt_result_exam_id" style="width:100%;max-width:400px">
                <option value="">— Select Exam —</option>
                <?php foreach ( $exams as $e ) :
                    $subj_id = get_post_meta( $e->ID, 'mt_exam_subject_id', true );
                    $subj    = $subj_id ? get_post( $subj_id ) : null;
                    $label   = esc_html( $e->post_title ) . ( $subj ? ' (' . esc_html( $subj->post_title ) . ')' : '' );
                    ?>
                    <option value="<?php echo $e->ID; ?>" <?php selected( $exam_id, $e->ID ); ?>>
                        <?php echo $label; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <?php if ( ! empty( $students ) ) : ?>
        <table class="wp-list-table widefat fixed striped mt-marks-table">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Roll/ID</th>
                    <th>Marks (out of 100)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $students as $stu ) :
                    $roll  = get_post_meta( $stu->ID, 'mt_student_id', true );
                    $marks = isset( $saved_marks[ $stu->ID ] ) ? $saved_marks[ $stu->ID ] : '';
                    ?>
                    <tr>
                        <td><?php echo esc_html( $stu->post_title ); ?></td>
                        <td><?php echo esc_html( $roll ?: '—' ); ?></td>
                        <td>
                            <input type="number"
                                   name="mt_result_marks[<?php echo $stu->ID; ?>]"
                                   value="<?php echo esc_attr( $marks ); ?>"
                                   min="0" max="100" step="0.5"
                                   placeholder="0–100"
                                   class="small-text" />
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p class="mt-notice">No students found. <a href="<?php echo admin_url('post-new.php?post_type=em_student'); ?>">Add students first.</a></p>
        <?php endif; ?>
    </div>
    <?php
}

// ─── Save Meta on post save ───────────────────────────────────────────────────
add_action( 'save_post', 'mt_exam_save_meta' );
function mt_exam_save_meta( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $post_type = get_post_type( $post_id );

    // Exam
    if ( 'em_exam' === $post_type && isset( $_POST['mt_exam_nonce'] ) &&
         wp_verify_nonce( $_POST['mt_exam_nonce'], 'mt_exam_save' ) ) {
        update_post_meta( $post_id, 'mt_exam_start_datetime', sanitize_text_field( $_POST['mt_exam_start_datetime'] ?? '' ) );
        update_post_meta( $post_id, 'mt_exam_end_datetime',   sanitize_text_field( $_POST['mt_exam_end_datetime'] ?? '' ) );
        update_post_meta( $post_id, 'mt_exam_subject_id',     absint( $_POST['mt_exam_subject_id'] ?? 0 ) );
    }

    // Student
    if ( 'em_student' === $post_type && isset( $_POST['mt_student_nonce'] ) &&
         wp_verify_nonce( $_POST['mt_student_nonce'], 'mt_student_save' ) ) {
        update_post_meta( $post_id, 'mt_student_id',    sanitize_text_field( $_POST['mt_student_id']    ?? '' ) );
        update_post_meta( $post_id, 'mt_student_email', sanitize_email( $_POST['mt_student_email'] ?? '' ) );
    }

    // Result
    if ( 'em_result' === $post_type && isset( $_POST['mt_result_nonce'] ) &&
         wp_verify_nonce( $_POST['mt_result_nonce'], 'mt_result_save' ) ) {
        update_post_meta( $post_id, 'mt_result_exam_id', absint( $_POST['mt_result_exam_id'] ?? 0 ) );

        $marks_raw    = $_POST['mt_result_marks'] ?? [];
        $marks_clean  = [];
        foreach ( $marks_raw as $student_id => $mark ) {
            $mark = trim( $mark );
            if ( $mark !== '' ) {
                $marks_clean[ absint( $student_id ) ] = min( 100, max( 0, floatval( $mark ) ) );
            }
        }
        update_post_meta( $post_id, 'mt_result_marks', $marks_clean );
    }
}
