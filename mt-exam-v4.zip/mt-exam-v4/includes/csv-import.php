<?php
defined( 'ABSPATH' ) || exit;

/**
 * Feature 6: Bulk Result Import via CSV
 *
 * FIX 2: CSV Import was silently failing because:
 *   a) fgetcsv() was not handling BOM (byte order mark) at start of file
 *      — Excel-saved CSVs have a UTF-8 BOM that corrupts the first header.
 *   b) Marks validation was too strict (0–100 only) — floatval edge cases.
 *   c) On empty $imported, function returned no success/error — user saw nothing.
 *   d) get_posts() inside the loop used 'post_status' => 'publish' but newly
 *      imported results ARE published, so the real issue was BOM breaking
 *      header detection which then bailed early with "Missing required column".
 *   e) Sample CSV download was calling exit() but headers may have already
 *      been sent — moved to use ob_clean() before output.
 *
 * Expected CSV format: student_id,exam_id,marks
 */

function mt_exam_import_page() {
    $messages = [];
    $errors   = [];

    // ── Handle sample CSV download before any output ──────────────────────────
    if ( isset( $_GET['download_sample'] ) && current_user_can( 'manage_options' ) ) {
        mt_exam_download_sample_csv();
        exit;
    }

    if ( isset( $_POST['mt_import_csv'] ) && check_admin_referer( 'mt_import_csv_action' ) ) {
        if ( ! empty( $_FILES['mt_csv_file']['tmp_name'] ) && $_FILES['mt_csv_file']['error'] === UPLOAD_ERR_OK ) {
            $result   = mt_exam_process_csv_import( $_FILES['mt_csv_file']['tmp_name'] );
            $messages = $result['messages'];
            $errors   = $result['errors'];
        } elseif ( ! empty( $_FILES['mt_csv_file']['error'] ) && $_FILES['mt_csv_file']['error'] !== UPLOAD_ERR_NO_FILE ) {
            // Translate PHP upload error codes to readable messages
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE   => 'File exceeds server upload_max_filesize limit.',
                UPLOAD_ERR_FORM_SIZE  => 'File exceeds MAX_FILE_SIZE limit set in the form.',
                UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded. Please try again.',
                UPLOAD_ERR_NO_TMP_DIR => 'Server has no temporary folder. Contact your host.',
                UPLOAD_ERR_CANT_WRITE => 'Server failed to save the uploaded file.',
                UPLOAD_ERR_EXTENSION  => 'A server PHP extension blocked the upload.',
            ];
            $code     = $_FILES['mt_csv_file']['error'];
            $errors[] = $upload_errors[ $code ] ?? "Upload error code: $code";
        } else {
            $errors[] = 'No file uploaded. Please choose a CSV file before clicking Import.';
        }
    }
    ?>
    <div class="wrap mt-exam-import">
        <h1>📥 Bulk Result Import</h1>
        <p class="description">
            Import results in bulk by uploading a CSV file. The file must have the headers:
            <code>student_id, exam_id, marks</code>.<br>
            <strong>Tip:</strong> Download the sample CSV below, fill in real Student IDs and Exam IDs
            (shown in the reference tables), then upload.
        </p>

        <p>
            <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'mt-exam-import', 'download_sample' => 1 ], admin_url( 'admin.php' ) ) ); ?>"
               class="button">
                ⬇ Download Sample CSV
            </a>
        </p>

        <?php if ( ! empty( $messages ) ) : ?>
            <div class="notice notice-success is-dismissible"><ul>
                <?php foreach ( $messages as $m ) : ?><li><?php echo esc_html( $m ); ?></li><?php endforeach; ?>
            </ul></div>
        <?php endif; ?>

        <?php if ( ! empty( $errors ) ) : ?>
            <div class="notice notice-error is-dismissible"><ul>
                <?php foreach ( $errors as $e ) : ?><li><?php echo esc_html( $e ); ?></li><?php endforeach; ?>
            </ul></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" style="margin-top:20px;">
            <?php wp_nonce_field( 'mt_import_csv_action' ); ?>
            <table class="form-table">
                <tr>
                    <th><label for="mt_csv_file">CSV File</label></th>
                    <td>
                        <input type="file" name="mt_csv_file" id="mt_csv_file" accept=".csv,text/csv" required />
                        <p class="description">
                            Accepted: <code>.csv</code> &nbsp;|&nbsp;
                            Max size: <code><?php echo esc_html( ini_get('upload_max_filesize') ); ?></code>
                        </p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="mt_import_csv" class="button button-primary" value="Import CSV" />
            </p>
        </form>

        <h2>CSV Format</h2>
        <table class="wp-list-table widefat fixed" style="max-width:520px">
            <thead><tr><th>Column</th><th>Description</th><th>Example</th></tr></thead>
            <tbody>
                <tr><td><code>student_id</code></td><td>WordPress Post ID of the student (see table below)</td><td>42</td></tr>
                <tr><td><code>exam_id</code></td><td>WordPress Post ID of the exam (see table below)</td><td>17</td></tr>
                <tr><td><code>marks</code></td><td>Marks obtained out of 100 (0–100, decimals allowed)</td><td>85.5</td></tr>
            </tbody>
        </table>

        <h2 style="margin-top:30px;">Reference: Existing Students &amp; Exams</h2>
        <p class="description">CSV mein <code>student_id</code> aur <code>exam_id</code> columns mein neeche diye gaye <strong>Post ID</strong> use karein.</p>
        <div style="display:flex;gap:30px;flex-wrap:wrap">
            <div>
                <h3>Students</h3>
                <table class="wp-list-table widefat fixed striped" style="width:300px">
                    <thead><tr><th>Post ID</th><th>Name</th><th>Roll/ID</th></tr></thead>
                    <tbody>
                    <?php
                    $students = get_posts( [ 'post_type' => 'em_student', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ] );
                    foreach ( $students as $s ) {
                        $roll = get_post_meta( $s->ID, 'mt_student_id', true );
                        echo '<tr><td><strong>' . $s->ID . '</strong></td><td>' . esc_html( $s->post_title ) . '</td><td>' . esc_html( $roll ?: '—' ) . '</td></tr>';
                    }
                    if ( empty( $students ) ) {
                        echo '<tr><td colspan="3"><em>No students yet.</em> <a href="' . admin_url('post-new.php?post_type=em_student') . '">Add students first</a>.</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            <div>
                <h3>Exams</h3>
                <table class="wp-list-table widefat fixed striped" style="width:380px">
                    <thead><tr><th>Post ID</th><th>Exam</th><th>Subject</th></tr></thead>
                    <tbody>
                    <?php
                    $exams = get_posts( [ 'post_type' => 'em_exam', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ] );
                    foreach ( $exams as $e ) {
                        $subj_id = get_post_meta( $e->ID, 'mt_exam_subject_id', true );
                        $subj    = $subj_id ? get_the_title( $subj_id ) : '—';
                        echo '<tr><td><strong>' . $e->ID . '</strong></td><td>' . esc_html( $e->post_title ) . '</td><td>' . esc_html( $subj ) . '</td></tr>';
                    }
                    if ( empty( $exams ) ) {
                        echo '<tr><td colspan="3"><em>No exams yet.</em> <a href="' . admin_url('post-new.php?post_type=em_exam') . '">Add exams first</a>.</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

// ─── Core Import Logic ────────────────────────────────────────────────────────
function mt_exam_process_csv_import( $file_path ) {
    $messages = [];
    $errors   = [];

    $handle = fopen( $file_path, 'r' );
    if ( ! $handle ) {
        return [ 'messages' => [], 'errors' => [ 'Could not open uploaded file. Check server permissions.' ] ];
    }

    // FIX: Strip UTF-8 BOM if present (Excel saves CSVs with BOM — EF BB BF)
    // Without this, the first header cell becomes "\xEF\xBB\xBFstudent_id"
    // which never matches 'student_id' and throws "Missing required column".
    $bom = fread( $handle, 3 );
    if ( $bom !== "\xEF\xBB\xBF" ) {
        // Not a BOM — rewind so we don't lose first 3 bytes
        rewind( $handle );
    }
    // If it IS a BOM we consumed it and the next read starts cleanly.

    $header = fgetcsv( $handle );
    if ( ! $header ) {
        fclose( $handle );
        return [ 'messages' => [], 'errors' => [ 'CSV file is empty or could not be parsed.' ] ];
    }

    // Normalize headers: trim whitespace + lowercase
    $header = array_map( function( $h ) { return strtolower( trim( $h ) ); }, $header );

    $required = [ 'student_id', 'exam_id', 'marks' ];
    $missing  = array_diff( $required, $header );
    if ( ! empty( $missing ) ) {
        fclose( $handle );
        return [
            'messages' => [],
            'errors'   => [ 'Missing required column(s): ' . implode( ', ', $missing ) . '. Found headers: ' . implode( ', ', $header ) ],
        ];
    }

    $idx_student = array_search( 'student_id', $header );
    $idx_exam    = array_search( 'exam_id',    $header );
    $idx_marks   = array_search( 'marks',      $header );

    // Aggregate marks per exam_id → [exam_id][student_id] = marks
    $exam_marks = [];
    $row_num    = 1; // header was row 1

    while ( ( $row = fgetcsv( $handle ) ) !== false ) {
        $row_num++;

        // Skip entirely blank lines
        if ( count( array_filter( $row, 'strlen' ) ) === 0 ) {
            continue;
        }

        // FIX: use count($header) not hard-coded 3 so extra columns don't break it
        if ( count( $row ) < count( $header ) ) {
            $errors[] = "Row $row_num: too few columns (" . count( $row ) . " found, " . count( $header ) . " expected) — skipped.";
            continue;
        }

        $student_id = absint( trim( $row[ $idx_student ] ) );
        $exam_id    = absint( trim( $row[ $idx_exam ] ) );
        $marks_raw  = trim( $row[ $idx_marks ] );

        // Validate IDs
        if ( ! $student_id ) {
            $errors[] = "Row $row_num: student_id must be a positive integer. Got: '" . esc_html( $row[ $idx_student ] ) . "' — skipped.";
            continue;
        }
        if ( ! $exam_id ) {
            $errors[] = "Row $row_num: exam_id must be a positive integer. Got: '" . esc_html( $row[ $idx_exam ] ) . "' — skipped.";
            continue;
        }

        // Validate marks — must be numeric
        if ( ! is_numeric( $marks_raw ) ) {
            $errors[] = "Row $row_num: marks must be a number. Got: '" . esc_html( $marks_raw ) . "' — skipped.";
            continue;
        }
        $marks = floatval( $marks_raw );
        if ( $marks < 0 || $marks > 100 ) {
            $errors[] = "Row $row_num: marks out of range (must be 0–100). Got: $marks — skipped.";
            continue;
        }

        // FIX: Verify post types with both 'publish' and 'any' status
        // get_post_type() returns false for non-existent posts, so check that first
        $s_type = get_post_type( $student_id );
        if ( false === $s_type || 'em_student' !== $s_type ) {
            $errors[] = "Row $row_num: student_id $student_id does not exist or is not a Student post — skipped.";
            continue;
        }
        $e_type = get_post_type( $exam_id );
        if ( false === $e_type || 'em_exam' !== $e_type ) {
            $errors[] = "Row $row_num: exam_id $exam_id does not exist or is not an Exam post — skipped.";
            continue;
        }

        $exam_marks[ $exam_id ][ $student_id ] = $marks;
    }
    fclose( $handle );

    if ( empty( $exam_marks ) && empty( $errors ) ) {
        $errors[] = 'No valid data rows found in the CSV. Make sure rows have student_id, exam_id, and marks.';
        return compact( 'messages', 'errors' );
    }

    if ( empty( $exam_marks ) ) {
        // All rows had errors — return early with errors
        return compact( 'messages', 'errors' );
    }

    // ── Find or create Result posts and save marks ─────────────────────────────
    $imported = 0;
    foreach ( $exam_marks as $exam_id => $marks_arr ) {

        // FIX: Search with 'any' status so draft results are also found
        $existing = get_posts( [
            'post_type'      => 'em_result',
            'numberposts'    => 1,
            'post_status'    => 'any',
            'meta_key'       => 'mt_result_exam_id',
            'meta_value'     => $exam_id,
        ] );

        if ( ! empty( $existing ) ) {
            $result_id  = $existing[0]->ID;
            $old_marks  = get_post_meta( $result_id, 'mt_result_marks', true );
            $old_marks  = is_array( $old_marks ) ? $old_marks : [];
            // Merge: CSV values overwrite existing values for same student
            $merged = array_merge( $old_marks, $marks_arr );
            $ok     = update_post_meta( $result_id, 'mt_result_marks', $merged );
            if ( false !== $ok ) {
                $messages[] = "✅ Updated results for exam #$exam_id — " . count( $marks_arr ) . ' student(s) imported/updated.';
            } else {
                $errors[] = "❌ Failed to update results for exam #$exam_id (database error).";
                continue;
            }
        } else {
            $exam_post = get_post( $exam_id );
            $title     = 'Results: ' . ( $exam_post ? $exam_post->post_title : "Exam #$exam_id" );

            $result_id = wp_insert_post( [
                'post_type'   => 'em_result',
                'post_status' => 'publish',
                'post_title'  => $title,
            ], true ); // pass true so WP_Error is returned on failure

            if ( is_wp_error( $result_id ) ) {
                $errors[] = "❌ Could not create result post for exam #$exam_id: " . $result_id->get_error_message();
                continue;
            }

            update_post_meta( $result_id, 'mt_result_exam_id', $exam_id );
            update_post_meta( $result_id, 'mt_result_marks',   $marks_arr );
            $messages[] = "✅ Created results for exam #$exam_id — " . count( $marks_arr ) . ' student(s) imported.';
        }
        $imported++;
    }

    if ( $imported > 0 ) {
        // Clear top students transient cache
        global $wpdb;
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_mt_top_students_%'" );
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_mt_top_students_%'" );
        $messages[] = "Import complete: $imported exam result(s) processed successfully.";
    }

    return compact( 'messages', 'errors' );
}

// ─── Sample CSV Download ──────────────────────────────────────────────────────
function mt_exam_download_sample_csv() {
    // FIX: ob_clean() to prevent "headers already sent" when output buffering is on
    if ( ob_get_level() ) {
        ob_clean();
    }

    header( 'Content-Type: text/csv; charset=UTF-8' );
    header( 'Content-Disposition: attachment; filename="mt-exam-sample-import.csv"' );
    header( 'Pragma: no-cache' );
    header( 'Expires: 0' );

    $out = fopen( 'php://output', 'w' );

    // FIX: Write UTF-8 BOM so Excel opens it correctly without garbling
    fwrite( $out, "\xEF\xBB\xBF" );

    fputcsv( $out, [ 'student_id', 'exam_id', 'marks' ] );

    // Pull real IDs if available, fall back to illustrative placeholders
    $students = get_posts( [ 'post_type' => 'em_student', 'numberposts' => 4, 'post_status' => 'publish' ] );
    $exams    = get_posts( [ 'post_type' => 'em_exam',    'numberposts' => 2, 'post_status' => 'publish' ] );

    if ( ! empty( $students ) && ! empty( $exams ) ) {
        foreach ( $students as $stu ) {
            foreach ( $exams as $ex ) {
                fputcsv( $out, [ $stu->ID, $ex->ID, rand( 50, 100 ) . '.0' ] );
            }
        }
    } else {
        // Placeholder sample when no real data exists yet
        $sample_rows = [
            [ 10, 20, 85.5 ],
            [ 10, 21, 92.0 ],
            [ 11, 20, 78.0 ],
            [ 11, 21, 65.5 ],
            [ 12, 20, 95.0 ],
            [ 12, 21, 88.0 ],
            [ 13, 20, 55.0 ],
            [ 13, 21, 72.5 ],
        ];
        foreach ( $sample_rows as $row ) {
            fputcsv( $out, $row );
        }
    }
    fclose( $out );
}
