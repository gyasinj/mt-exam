<?php
defined( 'ABSPATH' ) || exit;

/**
 * FIX 1: CPT Duplicate Issue
 *
 * Problem: CPTs were showing twice in the admin menu because:
 *   a) 'show_in_menu' => 'mt-exam-menu' tells WordPress to auto-add CPT
 *      menu items AND we were also manually adding them via add_submenu_page().
 *   b) WordPress auto-generates "Add New" + list links for each CPT.
 *
 * Solution:
 *   - Set 'show_in_menu' => FALSE on all CPTs so WordPress does NOT
 *     auto-create menu entries.
 *   - Our manual add_submenu_page() calls remain the single source of truth.
 */

add_action( 'init', 'mt_exam_register_post_types' );
function mt_exam_register_post_types() {

    // ── Student ───────────────────────────────────────────────────────────────
    register_post_type( 'em_student', [
        'label'               => 'Students',
        'labels'              => [
            'name'          => 'Students',
            'singular_name' => 'Student',
            'add_new_item'  => 'Add New Student',
            'edit_item'     => 'Edit Student',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => false,   // FIX: was 'mt-exam-menu' — caused duplicates
        'supports'            => [ 'title' ],
        'menu_icon'           => 'dashicons-groups',
        'capability_type'     => 'post',
    ] );

    // ── Subject ───────────────────────────────────────────────────────────────
    register_post_type( 'em_subject', [
        'label'               => 'Subjects',
        'labels'              => [
            'name'          => 'Subjects',
            'singular_name' => 'Subject',
            'add_new_item'  => 'Add New Subject',
            'edit_item'     => 'Edit Subject',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => false,   // FIX: was 'mt-exam-menu' — caused duplicates
        'supports'            => [ 'title' ],
        'capability_type'     => 'post',
    ] );

    // ── Exam ──────────────────────────────────────────────────────────────────
    register_post_type( 'em_exam', [
        'label'               => 'Exams',
        'labels'              => [
            'name'          => 'Exams',
            'singular_name' => 'Exam',
            'add_new_item'  => 'Add New Exam',
            'edit_item'     => 'Edit Exam',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => false,   // FIX: was 'mt-exam-menu' — caused duplicates
        'supports'            => [ 'title' ],
        'capability_type'     => 'post',
        'taxonomies'          => [ 'em_term' ],
    ] );

    // ── Result ────────────────────────────────────────────────────────────────
    register_post_type( 'em_result', [
        'label'               => 'Results',
        'labels'              => [
            'name'          => 'Results',
            'singular_name' => 'Result',
            'add_new_item'  => 'Add / Import Results',
            'edit_item'     => 'Edit Result',
        ],
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => false,   // FIX: was 'mt-exam-menu' — caused duplicates
        'supports'            => [ 'title' ],
        'capability_type'     => 'post',
    ] );

    // ── Term Taxonomy (academic session) ──────────────────────────────────────
    register_taxonomy( 'em_term', [ 'em_exam' ], [
        'label'             => 'Academic Terms',
        'labels'            => [
            'name'              => 'Academic Terms',
            'singular_name'     => 'Academic Term',
            'add_new_item'      => 'Add New Term',
            'edit_item'         => 'Edit Term',
        ],
        'public'            => false,
        'show_ui'           => true,
        'show_admin_column' => true,
        'hierarchical'      => false,
        'show_in_menu'      => false,   // FIX: prevent taxonomy from auto-adding to menu
        'rewrite'           => false,
    ] );
}

// ─── Custom Admin Menu ────────────────────────────────────────────────────────
add_action( 'admin_menu', 'mt_exam_admin_menu' );
function mt_exam_admin_menu() {
    add_menu_page(
        'MT Exam Manager',
        'MT Exam',
        'manage_options',
        'mt-exam-menu',
        '__return_null',
        'dashicons-welcome-learn-more',
        30
    );

    // Dashboard (same slug as menu = first item, no duplicate)
    add_submenu_page( 'mt-exam-menu', 'Dashboard',      'Dashboard',      'manage_options', 'mt-exam-menu',                                         'mt_exam_dashboard_page' );
    add_submenu_page( 'mt-exam-menu', 'Students',       'Students',       'manage_options', 'edit.php?post_type=em_student',                         null );
    add_submenu_page( 'mt-exam-menu', 'Subjects',       'Subjects',       'manage_options', 'edit.php?post_type=em_subject',                         null );
    add_submenu_page( 'mt-exam-menu', 'Exams',          'Exams',          'manage_options', 'edit.php?post_type=em_exam',                            null );
    add_submenu_page( 'mt-exam-menu', 'Results',        'Results',        'manage_options', 'edit.php?post_type=em_result',                          null );
    add_submenu_page( 'mt-exam-menu', 'Academic Terms', 'Academic Terms', 'manage_options', 'edit-tags.php?taxonomy=em_term&post_type=em_exam',      null );
    add_submenu_page( 'mt-exam-menu', 'Import CSV',     'Import CSV',     'manage_options', 'mt-exam-import',                                        'mt_exam_import_page' );
    add_submenu_page( 'mt-exam-menu', 'Student Report', 'Student Report', 'manage_options', 'mt-exam-report',      'mt_exam_report_page' );
    add_submenu_page( 'mt-exam-menu', 'Result Card',   'Result Card',   'manage_options', 'mt-exam-result-card', 'mt_exam_result_card_page' );
}

// ─── Highlight correct parent menu for CPT screens ────────────────────────────
// Without this, WordPress loses track of the active menu when editing a CPT
// because the CPT is no longer registered under 'mt-exam-menu' directly.
add_filter( 'parent_file', 'mt_exam_fix_parent_menu' );
add_filter( 'submenu_file', 'mt_exam_fix_submenu_menu' );

function mt_exam_fix_parent_menu( $parent_file ) {
    global $current_screen;
    $cpts = [ 'em_student', 'em_subject', 'em_exam', 'em_result' ];
    if ( isset( $current_screen->post_type ) && in_array( $current_screen->post_type, $cpts, true ) ) {
        $parent_file = 'mt-exam-menu';
    }
    if ( isset( $current_screen->taxonomy ) && $current_screen->taxonomy === 'em_term' ) {
        $parent_file = 'mt-exam-menu';
    }
    return $parent_file;
}

function mt_exam_fix_submenu_menu( $submenu_file ) {
    global $current_screen;
    $map = [
        'em_student' => 'edit.php?post_type=em_student',
        'em_subject' => 'edit.php?post_type=em_subject',
        'em_exam'    => 'edit.php?post_type=em_exam',
        'em_result'  => 'edit.php?post_type=em_result',
    ];
    if ( isset( $current_screen->post_type ) && isset( $map[ $current_screen->post_type ] ) ) {
        $submenu_file = $map[ $current_screen->post_type ];
    }
    if ( isset( $current_screen->taxonomy ) && $current_screen->taxonomy === 'em_term' ) {
        $submenu_file = 'edit-tags.php?taxonomy=em_term&post_type=em_exam';
    }
    return $submenu_file;
}

// mt_exam_dashboard_page() is defined in includes/reports.php
