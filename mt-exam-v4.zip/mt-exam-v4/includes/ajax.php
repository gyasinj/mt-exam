<?php
defined( 'ABSPATH' ) || exit;

/**
 * AJAX Handlers
 * SPEED FIX: Replaced N+1 query loops with bulk meta fetch using get_metadata()
 * and a single wpdb JOIN query for exam→term mapping.
 */

add_action( 'wp_ajax_mt_exam_list',        'mt_exam_ajax_list' );
add_action( 'wp_ajax_nopriv_mt_exam_list', 'mt_exam_ajax_list' );

function mt_exam_ajax_list() {
    check_ajax_referer( 'mt_exam_nonce', 'nonce' );

    $page     = max( 1, intval( $_REQUEST['page']     ?? 1 ) );
    $per_page = max( 1, intval( $_REQUEST['per_page'] ?? 10 ) );
    $now      = current_time( 'Y-m-d H:i:s' );

    // ── SPEED FIX: one query for all exams + all their meta at once ───────────
    global $wpdb;

    $exams = get_posts( [
        'post_type'   => 'em_exam',
        'numberposts' => -1,
        'post_status' => 'publish',
    ] );

    if ( empty( $exams ) ) {
        wp_send_json_success( [ 'exams' => [], 'total' => 0, 'page' => 1, 'per_page' => $per_page, 'total_pages' => 0 ] );
    }

    $exam_ids = array_column( $exams, 'ID' );

    // Bulk fetch all meta for these exams in ONE query
    $placeholders = implode( ',', array_fill( 0, count( $exam_ids ), '%d' ) );
    $meta_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT post_id, meta_key, meta_value
         FROM {$wpdb->postmeta}
         WHERE post_id IN ($placeholders)
         AND meta_key IN ('mt_exam_start_datetime','mt_exam_end_datetime','mt_exam_subject_id','mt_exam_custom_id')",
        ...$exam_ids
    ), ARRAY_A );

    // Index meta by post_id
    $meta_index = [];
    foreach ( $meta_rows as $r ) {
        $meta_index[ $r['post_id'] ][ $r['meta_key'] ] = $r['meta_value'];
    }

    // Bulk fetch subject titles in ONE query (get unique subject IDs first)
    $subject_ids = array_unique( array_filter( array_column( $meta_index, 'mt_exam_subject_id' ) ) );
    $subject_names = [];
    if ( ! empty( $subject_ids ) ) {
        $sp = implode( ',', array_fill( 0, count( $subject_ids ), '%d' ) );
        $subj_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ($sp)", ...$subject_ids
        ), ARRAY_A );
        foreach ( $subj_rows as $sr ) {
            $subject_names[ $sr['ID'] ] = $sr['post_title'];
        }
    }

    // Bulk fetch exam→term in ONE query via term_relationships + term_taxonomy
    $term_map = [];
    if ( ! empty( $exam_ids ) ) {
        $ep = implode( ',', array_fill( 0, count( $exam_ids ), '%d' ) );
        $term_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT tr.object_id AS exam_id, t.name AS term_name
             FROM {$wpdb->term_relationships} tr
             INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
             INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
             WHERE tr.object_id IN ($ep) AND tt.taxonomy = 'em_term'",
            ...$exam_ids
        ), ARRAY_A );
        foreach ( $term_rows as $tr ) {
            $term_map[ $tr['exam_id'] ] = $tr['term_name'];
        }
    }

    $current = []; $upcoming = []; $past = [];

    foreach ( $exams as $exam ) {
        $m      = $meta_index[ $exam->ID ] ?? [];
        $start  = $m['mt_exam_start_datetime'] ?? '';
        $end    = $m['mt_exam_end_datetime']   ?? '';
        $s_id   = $m['mt_exam_subject_id']     ?? '';
        $custom = $m['mt_exam_custom_id']       ?? '';

        $item = [
            'id'          => $exam->ID,
            'custom_id'   => $custom,
            'title'       => $exam->post_title,
            'subject'     => $subject_names[ $s_id ] ?? '',
            'term'        => $term_map[ $exam->ID ]  ?? '',
            'start'       => $start,
            'end'         => $end,
            'status'      => 'unknown',
            'edit_url'    => current_user_can( 'edit_posts' ) ? get_edit_post_link( $exam->ID, 'raw' ) : '',
        ];

        if ( $start && $end ) {
            if ( $now >= $start && $now <= $end )      { $item['status'] = 'current';  $current[]  = $item; }
            elseif ( $now < $start )                   { $item['status'] = 'upcoming'; $upcoming[] = $item; }
            else                                       { $item['status'] = 'past';     $past[]     = $item; }
        } else {
            $upcoming[] = $item;
        }
    }

    usort( $upcoming, fn( $a, $b ) => strcmp( $a['start'], $b['start'] ) );
    usort( $past,     fn( $a, $b ) => strcmp( $b['end'],   $a['end'] ) );

    $ordered = array_merge( $current, $upcoming, $past );
    $total   = count( $ordered );
    $paged   = array_slice( $ordered, ( $page - 1 ) * $per_page, $per_page );

    wp_send_json_success( [
        'exams'       => $paged,
        'total'       => $total,
        'page'        => $page,
        'per_page'    => $per_page,
        'total_pages' => ceil( $total / $per_page ),
    ] );
}

// ── Student Result Card AJAX ──────────────────────────────────────────────────
add_action( 'wp_ajax_mt_student_result_card',        'mt_student_result_card_ajax' );
add_action( 'wp_ajax_nopriv_mt_student_result_card', 'mt_student_result_card_ajax' );

function mt_student_result_card_ajax() {
    check_ajax_referer( 'mt_exam_nonce', 'nonce' );

    $roll_no = sanitize_text_field( trim( $_REQUEST['roll_no'] ?? '' ) );
    if ( ! $roll_no ) {
        wp_send_json_error( [ 'message' => 'Roll number / Student ID required.' ] );
    }

    // Find student by roll number field
    $students = get_posts( [
        'post_type'  => 'em_student',
        'numberposts'=> 1,
        'meta_key'   => 'mt_student_id',
        'meta_value' => $roll_no,
    ] );

    if ( empty( $students ) ) {
        wp_send_json_error( [ 'message' => "No student found with Roll No: $roll_no" ] );
    }

    $student    = $students[0];
    $student_wp_id = $student->ID;

    global $wpdb;

    // Get all result posts that contain this student's marks — bulk query
    $result_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.ID AS result_id, pm_exam.meta_value AS exam_id, pm_marks.meta_value AS marks_serial
         FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm_exam  ON pm_exam.post_id  = p.ID AND pm_exam.meta_key  = 'mt_result_exam_id'
         INNER JOIN {$wpdb->postmeta} pm_marks ON pm_marks.post_id = p.ID AND pm_marks.meta_key = 'mt_result_marks'
         WHERE p.post_type = 'em_result' AND p.post_status = 'publish'",
    ), ARRAY_A );

    // Filter only results where this student has marks.
    // KEY FIX: PHP serializes array keys as strings. After maybe_unserialize()
    // the student ID key is a STRING (e.g. "42"), but $student_wp_id is INT.
    // We cast both sides to string for a reliable lookup.
    $student_wp_id_str = (string) $student_wp_id;
    $student_results   = [];
    foreach ( $result_rows as $row ) {
        $marks = maybe_unserialize( $row["marks_serial"] );
        if ( ! is_array( $marks ) ) continue;
        if ( isset( $marks[ $student_wp_id_str ] ) ) {
            $mark_val = $marks[ $student_wp_id_str ];
        } elseif ( isset( $marks[ $student_wp_id ] ) ) {
            $mark_val = $marks[ $student_wp_id ];
        } else {
            continue;
        }
        $student_results[] = [
            "exam_id" => intval( $row["exam_id"] ),
            "marks"   => floatval( $mark_val ),
        ];
    }

    if ( empty( $student_results ) ) {
        wp_send_json_error( [ 'message' => "No results found for student: {$student->post_title}" ] );
    }

    // Bulk fetch exam data
    $exam_ids = array_unique( array_column( $student_results, 'exam_id' ) );
    $ep = implode( ',', array_fill( 0, count( $exam_ids ), '%d' ) );

    $exam_meta_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta}
         WHERE post_id IN ($ep)
         AND meta_key IN ('mt_exam_subject_id','mt_exam_custom_id','mt_exam_start_datetime')",
        ...$exam_ids
    ), ARRAY_A );

    $exam_meta = [];
    foreach ( $exam_meta_rows as $r ) {
        $exam_meta[ $r['post_id'] ][ $r['meta_key'] ] = $r['meta_value'];
    }

    // Bulk fetch exam titles
    $exam_titles = [];
    $exam_posts = $wpdb->get_results( $wpdb->prepare(
        "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ($ep)", ...$exam_ids
    ), ARRAY_A );
    foreach ( $exam_posts as $ep_row ) {
        $exam_titles[ $ep_row['ID'] ] = $ep_row['post_title'];
    }

    // Bulk fetch subject names
    $subj_ids = array_unique( array_filter( array_column( $exam_meta, 'mt_exam_subject_id' ) ) );
    $subject_names = [];
    if ( ! empty( $subj_ids ) ) {
        $sp = implode( ',', array_fill( 0, count( $subj_ids ), '%d' ) );
        $srows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ($sp)", ...$subj_ids
        ), ARRAY_A );
        foreach ( $srows as $sr ) {
            $subject_names[ $sr['ID'] ] = $sr['post_title'];
        }
    }

    // Exam→term bulk fetch
    $term_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT tr.object_id AS exam_id, t.name AS term_name
         FROM {$wpdb->term_relationships} tr
         INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
         INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
         WHERE tr.object_id IN ($ep) AND tt.taxonomy = 'em_term'",
        ...$exam_ids
    ), ARRAY_A );
    $exam_term = [];
    foreach ( $term_rows as $tr ) {
        $exam_term[ $tr['exam_id'] ] = $tr['term_name'];
    }

    // Build result rows
    $rows = [];
    $total_marks = 0; $count = 0;
    foreach ( $student_results as $sr ) {
        $eid   = $sr['exam_id'];
        $m     = $exam_meta[ $eid ] ?? [];
        $subj  = $subject_names[ $m['mt_exam_subject_id'] ?? 0 ] ?? 'N/A';
        $rows[] = [
            'exam'    => $exam_titles[ $eid ] ?? "Exam #$eid",
            'subject' => $subj,
            'term'    => $exam_term[ $eid ] ?? '—',
            'marks'   => $sr['marks'],
            'grade'   => mt_exam_grade( $sr['marks'] ),
            'date'    => substr( $m['mt_exam_start_datetime'] ?? '', 0, 10 ),
        ];
        $total_marks += $sr['marks'];
        $count++;
    }

    // Sort by date newest first
    usort( $rows, fn( $a, $b ) => strcmp( $b['date'], $a['date'] ) );

    wp_send_json_success( [
        'student'     => $student->post_title,
        'roll_no'     => $roll_no,
        'email'       => get_post_meta( $student_wp_id, 'mt_student_email', true ),
        'results'     => $rows,
        'total_marks' => $total_marks,
        'avg'         => $count > 0 ? round( $total_marks / $count, 1 ) : 0,
        'exams_taken' => $count,
    ] );
}

function mt_exam_grade( $marks ) {
    if ( $marks >= 90 ) return 'A+';
    if ( $marks >= 80 ) return 'A';
    if ( $marks >= 70 ) return 'B';
    if ( $marks >= 60 ) return 'C';
    if ( $marks >= 50 ) return 'D';
    return 'F';
}
