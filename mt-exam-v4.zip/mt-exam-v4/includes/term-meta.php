<?php
defined( 'ABSPATH' ) || exit;

/**
 * Feature 1: Admin Term Creation
 * Add start/end date fields to the em_term taxonomy add/edit forms.
 */

// ─── Add Term Form Fields ─────────────────────────────────────────────────────
add_action( 'em_term_add_form_fields', 'mt_exam_term_add_fields' );
function mt_exam_term_add_fields() {
    ?>
    <div class="form-field mt-term-field">
        <label for="mt_term_start_date">Start Date</label>
        <input type="date" name="mt_term_start_date" id="mt_term_start_date" />
        <p class="description">The first day of this academic term.</p>
    </div>
    <div class="form-field mt-term-field">
        <label for="mt_term_end_date">End Date</label>
        <input type="date" name="mt_term_end_date" id="mt_term_end_date" />
        <p class="description">The last day of this academic term.</p>
    </div>
    <?php
}

// ─── Edit Term Form Fields ────────────────────────────────────────────────────
add_action( 'em_term_edit_form_fields', 'mt_exam_term_edit_fields', 10, 2 );
function mt_exam_term_edit_fields( $term, $taxonomy ) {
    $start = get_term_meta( $term->term_id, 'mt_term_start_date', true );
    $end   = get_term_meta( $term->term_id, 'mt_term_end_date', true );
    ?>
    <tr class="form-field">
        <th scope="row"><label for="mt_term_start_date">Start Date</label></th>
        <td>
            <input type="date" name="mt_term_start_date" id="mt_term_start_date"
                   value="<?php echo esc_attr( $start ); ?>" />
            <p class="description">The first day of this academic term.</p>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row"><label for="mt_term_end_date">End Date</label></th>
        <td>
            <input type="date" name="mt_term_end_date" id="mt_term_end_date"
                   value="<?php echo esc_attr( $end ); ?>" />
            <p class="description">The last day of this academic term.</p>
        </td>
    </tr>
    <?php
}

// ─── Save Term Meta ───────────────────────────────────────────────────────────
add_action( 'created_em_term', 'mt_exam_save_term_meta', 10, 2 );
add_action( 'edited_em_term',  'mt_exam_save_term_meta', 10, 2 );
function mt_exam_save_term_meta( $term_id, $tt_id ) {
    if ( isset( $_POST['mt_term_start_date'] ) ) {
        update_term_meta( $term_id, 'mt_term_start_date', sanitize_text_field( $_POST['mt_term_start_date'] ) );
    }
    if ( isset( $_POST['mt_term_end_date'] ) ) {
        update_term_meta( $term_id, 'mt_term_end_date', sanitize_text_field( $_POST['mt_term_end_date'] ) );
    }
}

// ─── Show dates in term list table ───────────────────────────────────────────
add_filter( 'manage_edit-em_term_columns', 'mt_exam_term_columns' );
function mt_exam_term_columns( $columns ) {
    $columns['mt_start'] = 'Start Date';
    $columns['mt_end']   = 'End Date';
    return $columns;
}

add_filter( 'manage_em_term_custom_column', 'mt_exam_term_column_content', 10, 3 );
function mt_exam_term_column_content( $content, $column_name, $term_id ) {
    if ( 'mt_start' === $column_name ) {
        return esc_html( get_term_meta( $term_id, 'mt_term_start_date', true ) ?: '—' );
    }
    if ( 'mt_end' === $column_name ) {
        return esc_html( get_term_meta( $term_id, 'mt_term_end_date', true ) ?: '—' );
    }
    return $content;
}
